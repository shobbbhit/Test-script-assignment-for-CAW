/*
 * Set of test script for testing Website Guru99 Bank
 * The test scripts is developed using Selenium Framework
 *
 */
import java.io.FileReader;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class demoautomation {

    public static void main(String[] args) throws Exception {
        // Read JSON data from file
        FileReader reader = new FileReader("C:\\Users\\TUF\\Downloads\\string-to-json-online.json\\");
        JSONParser parser = new JSONParser();
        JSONArray jsonArray = (JSONArray) parser.parse(reader);

        // Convert JSON data to string
        StringBuilder jsonDataString = new StringBuilder("[");
        for (Object jsonObject : jsonArray) {
            jsonDataString.append(jsonObject.toString()).append(",");
        }
        jsonDataString.deleteCharAt(jsonDataString.length() - 1);
        jsonDataString.append("]");

        // Set path to Edge WebDriver executable
        System.setProperty("webdriver.edge.driver", "C:\\browserdriver\\msedgedriver.exe");

        // Open web page and locate textbox
        WebDriver driver = new EdgeDriver();
        driver.get("https://testpages.herokuapp.com/styled/tag/dynamic-table.html");

        driver.findElement(By.xpath("/html/body/div/div[3]/details/summary")).click();

        driver.findElement(By.xpath("//*[@id=\"jsondata\"]")).clear();

        driver.findElement(By.xpath("//*[@id=\"jsondata\"]")).sendKeys(jsonDataString.toString());

        driver.findElement(By.id("refreshtable")).click();
    }
}

